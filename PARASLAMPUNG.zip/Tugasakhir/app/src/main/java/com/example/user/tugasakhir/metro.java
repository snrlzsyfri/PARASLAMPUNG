package com.example.user.tugasakhir;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class metro extends AppCompatActivity {
    Button mapstaqwa;
    Button mapsdamraman  ;
    Button mapsmerdeka;
    Button mapspalem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro);

        mapstaqwa = findViewById(R.id.mapstaqwa);
        mapstaqwa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.114712";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.306807"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsdamraman = findViewById(R.id.mapsdamraman);
        mapsdamraman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.055202";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.316994"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsmerdeka= findViewById(R.id.mapsmerdeka);
        mapsmerdeka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.114692";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.308251"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapspalem= findViewById(R.id.mapspalem);
        mapspalem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.125375";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.287277"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });

    }
}
