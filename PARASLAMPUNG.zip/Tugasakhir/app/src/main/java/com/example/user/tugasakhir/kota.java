package com.example.user.tugasakhir;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kota extends AppCompatActivity {
    private Button button3,button4,button5,button6,button7,button12,button13,button14;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kota);

        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button12=findViewById(R.id.button12);
        button13=findViewById(R.id.button13);
        button14=findViewById(R.id.button14);


        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button3intent = new Intent(kota.this,bandarlampung.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button3intent);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button4intent = new Intent(kota.this, metro.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button4intent);
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button5intent = new Intent(kota.this,lampungbarat.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button5intent);
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button6intent = new Intent(kota.this,lampungtimur.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button6intent);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button7intent = new Intent(kota.this,lampungselatan.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button7intent);
            }
        });

        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button12intent = new Intent(kota.this,pesisirbarat.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button12intent);
            }
        });

        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button13intent = new Intent(kota.this,pesawaran.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button13intent);
            }
        });

        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent button14intent = new Intent(kota.this,tanggamus.class); //cariintent itu objek untuk pindah activity (pake intent)
                //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                startActivity(button14intent);
            }
        });

    }
}
