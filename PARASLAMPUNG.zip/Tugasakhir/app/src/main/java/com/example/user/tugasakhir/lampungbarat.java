package com.example.user.tugasakhir;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class lampungbarat extends AppCompatActivity {
    Button mapsbatuberak;
    Button mapssekuting  ;
    Button mapsbatususun;
    Button mapspura;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lampungbarat);
        mapsbatuberak = findViewById(R.id.mapsbatuberak);
        mapsbatuberak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.051218";// isi latitude dari alamat tempat wisatanya
                String longitude = "104.529922"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapssekuting = findViewById(R.id.mapssekuting);
        mapssekuting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.018348";// isi latitude dari alamat tempat wisatanya
                String longitude = "104.116283"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsbatususun= findViewById(R.id.mapsbatususun);
        mapsbatususun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.042938";// isi latitude dari alamat tempat wisatanya
                String longitude = "104.071921"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapspura = findViewById(R.id.mapspura);
        mapspura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.089776";// isi latitude dari alamat tempat wisatanya
                String longitude = "-104.495954"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });

    }
}
