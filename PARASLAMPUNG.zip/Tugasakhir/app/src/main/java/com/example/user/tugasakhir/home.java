package com.example.user.tugasakhir;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;


public class home extends AppCompatActivity {

        private RelativeLayout cari,profile,rating,review ;//ngasi objek baru dg nama cari,dkk.

        @Override
        protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home);

//inisialisasi id masing masing
            cari = findViewById(R.id.cari);
            profile = findViewById(R.id.profile);
            rating = findViewById(R.id.rating);
            review = findViewById(R.id.review);

            //supaya objek bisa d klik
            cari.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent cariintent = new Intent(home.this,kota.class); //cariintent itu objek untuk pindah activity (pake intent)
                    //MainActivity.this,Home.class itu activity saat ini,activity tujuan
                    startActivity(cariintent);
                }
            });
            profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent profileintent = new Intent( home.this,profil.class);
                    startActivity(profileintent);

                }
            });
            rating.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent ratingintent = new Intent(home.this, rate.class);
                    startActivity(ratingintent);
                }
            });
            review.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent reviewintent = new Intent(home.this, komentar.class);
                    startActivity(reviewintent);
                }
            });
        }
    }
