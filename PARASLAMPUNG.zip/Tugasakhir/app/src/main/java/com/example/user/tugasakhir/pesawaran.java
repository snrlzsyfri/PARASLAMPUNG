package com.example.user.tugasakhir;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class pesawaran extends AppCompatActivity {
    Button mapsmuncakpas;
    Button mapsniagara ;
    Button mapsmutun;
    Button mapsarta;
    Button mapstirta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesawaran);

        mapsmuncakpas = findViewById(R.id.mapsmuncakpas);
        mapsmuncakpas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.495785";// isi latitude dari alamat tempat wisatanya
                String longitude = " 105.225639"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsniagara = findViewById(R.id.mapsniagara);
        mapsniagara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.587243";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.024821"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsmutun= findViewById(R.id.mapsmutun);
        mapsmutun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.514587";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.263316"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsarta= findViewById(R.id.mapsarta);
        mapsarta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.492974";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.252250"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });

        mapstirta= findViewById(R.id.mapstirta);
        mapstirta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "  -5.488032";// isi latitude dari alamat tempat wisatanya
                String longitude = " 105.244005"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }
        });
    }
}
