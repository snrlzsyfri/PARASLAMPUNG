package com.example.user.tugasakhir;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class lampungtimur extends AppCompatActivity {
    Button mapskerangmas;
    Button mapsmangrove  ;
    Button mapspurba;
    Button mapskambas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lampungtimur);

        mapskerangmas = findViewById(R.id.mapskerangmas);
        mapskerangmas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.371366";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.819096"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsmangrove = findViewById(R.id.mapsmangrove);
        mapsmangrove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.297832";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.826650"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapspurba= findViewById(R.id.mapspurba);
        mapspurba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.300743";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.571221"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapskambas= findViewById(R.id.mapskambas);
        mapskambas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -4.927480";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.776918"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
    }
}
