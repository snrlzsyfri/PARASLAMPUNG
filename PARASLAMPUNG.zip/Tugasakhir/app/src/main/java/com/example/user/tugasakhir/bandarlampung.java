package com.example.user.tugasakhir;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class bandarlampung extends AppCompatActivity {
    Button mapswawai;
    Button mapsputu  ;
    Button mapssakura;
    Button mapskedaton;
    Button mapsgajah;
    Button mapsteropong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bandarlampung);mapswawai = findViewById(R.id.mapswawai);
        mapswawai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "13.057840";// isi latitude dari alamat tempat wisatanya
                String longitude = "101.507270"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsputu = findViewById(R.id.mapsputu);
        mapsputu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.427016";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.218310"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapssakura= findViewById(R.id.mapssakura);
        mapssakura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.403144 ";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.222366"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapskedaton = findViewById(R.id.mapskedaton);
        mapskedaton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.436698";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.222848"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsgajah= findViewById(R.id.mapsgajah);
        mapsgajah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = " -5.422311, ";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.260446"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
        mapsteropong = findViewById(R.id.mapsteropong);
        mapsteropong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = "-5.404498";// isi latitude dari alamat tempat wisatanya
                String longitude = "105.253389"; // isi longitude dari alamat tempat wisatanya
                Intent mapIntent = new Intent(Intent.ACTION_VIEW);
                //mapIntent.setData(Uri.parse("geo:0,0?q="+latitude+","+longitude)); // cuman marker in di google maps aja
                mapIntent.setData(Uri.parse("google.navigation:q=" + latitude + "," + longitude)); //untuk langsung navigasi
                Intent chooser = Intent.createChooser(mapIntent, "Buka Maps");
                startActivity(chooser);
            }

        });
    }
}
